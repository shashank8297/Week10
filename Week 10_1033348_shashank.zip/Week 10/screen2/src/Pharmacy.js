import React from "react";
import './Pharmacy.css';
class Pharmacy extends React.Component {
    constructor() {
        super();
        this.state = {
            fields: {},
            errors: {}
        }
        this.handleChange = this.handleChange.bind(this);
        this.submituserRegistrationForm = this.submituserRegistrationForm.bind(this);
    };
    handleChange(e) {
        let fields = this.state.fields;
        fields[e.target.name] = e.target.value;
        this.setState({
            fields
        });
    }
    submituserRegistrationForm(e) {
        e.preventDefault();
        if (this.validateForm()) {
            alert("form submited succesfully");
        }
    }
    validateForm() {
        let fields = this.state.fields
        let fvalid = true;
        let errors = {};
        /*
        if (fields["mobileno"].length < 10) {
            fvalid = false;
            errors["mobileno"] = "*Please enter full mobile number.";
        }
        if (fields["vendorid"].length<10) {
            fvalid = false;
            errors["vendorid"] = "*Vendor ID cannot be less than 10 characters.";
        }
        if (fields["password"].length < 8) {
            fvalid = false;
            errors["password"] = "*Password must be minimum 8 characters.";
        }
        if (fields["retypepassword"].length < 8) {
            fvalid = false;
            errors["retypepassword"] = "*Password must be minimum 8 characters.";
        }
        if (fields["password"]!=fields["retypepassword"]) {
            fvalid = false;
            errors["retypepassword"] = "*Password must be same.";
        }
        if (!fields["username"]) {
            fvalid = false;
            errors["username"] = "*Please enter your Name.";
        }
        if (!fields["vendorid"]) {
            fvalid = false;
            errors["vendorid"] = "*Please enter your Vendor ID.";
        }
        if (!fields["address"]) {
            fvalid = false;
            errors["address"] = "*Please enter your Address.";
        }
        if (!fields["mobileno"]) {
            fvalid = false;
            errors["mobileno"] = "*Please enter your mobile no.";
        }
        if (!fields["password"]) {
            fvalid = false;
            errors["password"] = "*Please enter your password.";
        }
        if (!fields["retypepassword"]) {
            fvalid = false;
            errors["retypepassword"] = "*Please re-enter your password.";
        }
        */
        if (!fields["username"]) {
            fvalid = false
            errors["username"] = "*A Space can't be Username.";
        }
        if (!fields["mobileno"]) {
            fvalid = false;
            errors["mobileno"] = "*Please enter your mobile no.";
        }
        if (!fields["address"]) {
            fvalid = false;
            errors["address"] = "*Please enter your email-ID.";
        }
        var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
        if(!pattern.test(fields["emaild"])){
            fvalid = false;
            errors["emailid"] = "Please enter a valid email address,Invalid email format,Missing '@' symbol, and Invalid domain name.";
        }

        if (!fields["vendorid"]) {
            fvalid = false;
            errors["vendorid"] = "*Please enter your Vendor-ID.";
        }

        if (!fields["password"]) {
            fvalid = false;
            errors["password"] = "*Please enter your password.";
        }
        

        if(fields["password"] != fields["retypepassword"]){
            fvalid = false;
            errors["retypepassword"] = "*Password Dosen't Match."
        }
        this.setState({
            errors: errors
        });
        return fvalid;
    }
    render() {
        return (
            <table id="table" cellSpacing={2}>
                <tr>
                    <td align="center">
                        <div id="main-registration-container">
                            <div id="register">
                                <form method="post" name="userRegistrationForm" onSubmit={this.submituserRegistrationForm}>
                                    <h3>Register New Vendor</h3>
                                    <input type="text" name="username" placeholder="Enter Name" value={this.state.fields.username} onChange={this.handleChange} />
                                    <div className="errorMsg">{this.state.errors.username}</div>
                                    
                                    <input type="text" name="mobileno" placeholder="Enter Phone number" value={this.state.fields.mobileno} onChange={this.handleChange} />
                                    <div className="errorMsg">{this.state.errors.mobileno}</div>

                                    <input type="text" name="address" placeholder="Enter Address" value={this.state.fields.address} onChange={this.handleChange} />
                                    <div className="errorMsg">{this.state.errors.address}</div>
                                    
                                    <input type="text" name="vendorid" placeholder="Enter Vendor ID" value={this.state.fields.vendorid} onChange={this.handleChange} />
                                    <div className="errorMsg">{this.state.errors.vendorid}</div>

                                    <input type="password" name="password" placeholder="Enter Password" value={this.state.fields.password} onChange={this.handleChange} />
                                    <div className="errorMsg">{this.state.errors.password}</div>

                                    <input type="password" name="retypepassword" placeholder="Retype Password" value={this.state.fields.retypepassword} onChange={this.handleChange} />
                                    <div className="errorMsg">{this.state.errors.retypepassword}</div>
                                    <input type="submit" className="button" value="Submit" />
                                </form>
                            </div>
                        </div>
                    </td>
                    <td align="center">
                        <img src="./images/pharmacy.png" className="images"/>
                    </td>
                </tr>
            </table>
        );
    }
}
export default Pharmacy;