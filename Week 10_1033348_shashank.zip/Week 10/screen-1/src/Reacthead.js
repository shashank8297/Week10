import React from "react";
import './Reacthead.css';

function Reacthead(){
    return(
        <div className="screen1" >
            <div className="react">
                <img src="./images/react.png" alt="React"/>
            </div>
            <div className="font">
                <p className="fontline" align="center">LOADING</p>
                <p className="fontline" align="center">SCREEN</p>
                <p className="fontline" align="center">REACTJS</p>
            </div>
            <div>
                <image src="./images/react.png" alt="loading"/>
            </div>
        </div>
        
    );
}

export default Reacthead
