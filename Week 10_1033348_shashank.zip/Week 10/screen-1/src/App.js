import './App.css';
import Reacthead from './Reacthead';
//import {AiOutlineLoading3Quarters} from "AiOutlineLoading3Quarters";

function App() {
  return (
    <div>
      <Reacthead/>
    </div>
  );
}

export default App;
