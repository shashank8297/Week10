import DataService2 from "./DataService2";
import { useEffect, useState } from "react";

function DataComponent2() {

    const [database2,setData2] = useState([])
    
    useEffect(()=>{
        getData2()
    },[])

    const getData2 = () =>{
        DataService2.getData2().then((Response) =>{
            setData2(Response.data)
            console.log(Response.data);
            console.log(Response.data.data);
        });
    };

    return (
        <div>
            <h1><center>Database Table</center></h1><hr />
            <table align="center" border={2} cellPadding={10}>
                <thead>
                    <th>ID Nation</th>
                    <th>Population</th>
                    <th>Year</th>
                </thead>
                <tbody>
                    {
                        database2.map(
                            database2 =>
                                <tr key={database2.data.data}>
                                    <td>{database2.data.data.Population}</td>

                                </tr>
                        )
                    }
                </tbody>
            </table>
        </div>
    );
}

export default DataComponent2;