import React from "react";
import axios from "axios";

const DATABASE2 = "https://datausa.io/api/data?drilldowns=Nation&measures=Population"

class DataService2{
    getData2(){
        return axios.get(DATABASE2);
    }
   
}

export default new DataService2;