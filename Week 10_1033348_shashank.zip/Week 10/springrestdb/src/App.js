import './App.css';
import DataComponent2 from './DataComponent2';

function App() {
  return (
    <div>
      
      <DataComponent2/>
    </div>
  );
}

export default App;
